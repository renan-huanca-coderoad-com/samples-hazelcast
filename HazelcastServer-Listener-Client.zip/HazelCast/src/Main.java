import com.hazelcast.core.*;
import com.hazelcast.config.*;
import com.hazelcast.client.config.*;

import java.io.IOException;
import java.util.Map;
import java.util.Queue;

public class Main {
    public static void main(String[] args) throws IOException {

       // loadConfigXMl();
//        RunHazecastFromXML();
                RunDefaultHazeCastServe();
    }

    public  static void  loadConfigXMl() throws IOException {
       // ClientConfig cfg = new XmlClientConfigBuilder("").build();


        Config cfg = new ClasspathXmlConfig("node2.xml");
        Hazelcast.newHazelcastInstance(cfg);

    }

    public static void RunHazecastFromXML()
    {
        Config cfg = new ClasspathXmlConfig("node1.xml");
        HazelcastInstance instance =Hazelcast.newHazelcastInstance(cfg);

        Map<Integer, String> mapCustomers = instance.getMap("customersNBS");
        mapCustomers.put(1, "Joe");
        mapCustomers.put(2, "Ali");
        mapCustomers.put(3, "Avi");

        System.out.println("Customer with key 1: "+ mapCustomers.get(1));
        System.out.println("Map Size:" + mapCustomers.size());

        Queue<String> queueCustomers = instance.getQueue("customers");
        queueCustomers.offer("Tom");
        queueCustomers.offer("Mary");
        queueCustomers.offer("Jane");
        System.out.println("First customer: " + queueCustomers.poll());
        System.out.println("Second customer: "+ queueCustomers.peek());
        System.out.println("Queue size: " + queueCustomers.size());

    }

    public static void RunDefaultHazeCastServe()
    {
        HazelcastInstance hazelcastInstance = Hazelcast.newHazelcastInstance();
        Map<Integer, String> customers = hazelcastInstance.getMap( "customers" );
        customers.put( 1, "Joe" );
        customers.put( 2, "Ali" );
        customers.put( 3, "Avi" );

        System.out.println( "Customer with key 1: " + customers.get(1) );
        System.out.println( "Map Size:" + customers.size() );

        Queue<String> queueCustomers = hazelcastInstance.getQueue( "customers" );
        queueCustomers.offer( "Tomy" );
        queueCustomers.offer( "Maryy" );
        queueCustomers.offer( "Janee" );
        System.out.println( "First customer: " + queueCustomers.poll() );
        System.out.println( "Second customer: "+ queueCustomers.peek() );
        System.out.println( "Queue size: " + queueCustomers.size() );
    }


}

