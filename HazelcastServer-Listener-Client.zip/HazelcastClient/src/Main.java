import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.client.config.ClientNetworkConfig;
import com.hazelcast.client.config.XmlClientConfigBuilder;
import com.hazelcast.config.CacheConfig;
import com.hazelcast.config.ClasspathXmlConfig;
import com.hazelcast.config.NearCacheConfig;

import java.io.IOException;
import java.util.Map;
import java.util.Queue;
import com.hazelcast.client.config.ClientConfig;
import com.hazelcast.client.HazelcastClient;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;
/**
 * Created by user on 6/3/2016.
 */
public class Main {
    public static void main(String[] args) throws IOException {

      // ClientXML();
                ClientDefault();
    }

    public static void ClientXML() throws IOException {
        ClientConfig clientConfig = new XmlClientConfigBuilder("hazelcastClient.xml").build();
        ClientNetworkConfig networkConfig = clientConfig.getNetworkConfig();
        NearCacheConfig nearCacheConfig = new NearCacheConfig();
        nearCacheConfig.setName("customersNBS");
        clientConfig.addNearCacheConfig(nearCacheConfig);
    }
    public static void ClientDefault()
    {
        ClientConfig clientConfig = new ClientConfig();
        HazelcastInstance hazelcastInstance = HazelcastClient.newHazelcastClient( clientConfig );
        IMap customers = hazelcastInstance.getMap( "customers" );
        System.out.println( "Map Size:" + customers.size() );
        customers.put(4,"test1");
        System.out.println( "Map Size:" + customers.size() );

    }
}
