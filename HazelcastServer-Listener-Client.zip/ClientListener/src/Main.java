import com.hazelcast.core.Hazelcast;
import com.hazelcast.core.HazelcastInstance;
import com.hazelcast.core.IMap;

import java.io.IOException;

/**
 * Created by user on 6/3/2016.
 */
public class Main {
    public static void main(String[] args) throws IOException {
        HazelcastInstance hz = Hazelcast.newHazelcastInstance();
        IMap<String, String> map = hz.getMap("customers");
        map.addEntryListener( new MyEntryListener(), true );
        System.out.println( "EntryListener registered" );
    }
}
